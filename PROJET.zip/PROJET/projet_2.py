# UVSQolor – Projet complet (Tkinter + Pillow + NumPy)

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from PIL import Image, ImageTk
import numpy as np
import INTERFACE

# =========================
# Variables globales
# =========================
canvas = None
photo_image = None

image_originale = None
image_courante = None
matrice_pixels = None

historique_undo = []
historique_redo = []

# =========================
# Fonctions utilitaires
# =========================
def sauvegarder_etat():
    global matrice_pixels
    if matrice_pixels is not None:
        historique_undo.append(matrice_pixels.copy())
        historique_redo.clear()


def rafraichir_affichage():
    global matrice_pixels, photo_image

    image = Image.fromarray(matrice_pixels)
    photo_image = ImageTk.PhotoImage(image)

    INTERFACE.canvas.config(width=image.width, height=image.height)
    INTERFACE.canvas.create_image(0, 0, anchor=tk.NW, image=photo_image)


# =========================
# Ouverture / Sauvegarde
# =========================
def ouvrir_image():
    global image_originale
    global image_courante
    global matrice_pixels

    chemin = filedialog.askopenfilename(
        filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp")]
    )

    if not chemin:
        return

    image_originale = Image.open(chemin).convert("RGB")
    image_courante = image_originale.copy()

    matrice_pixels = np.array(image_courante)

    rafraichir_affichage()
    INTERFACE.activer_menus()



def sauvegarder_image():
    global matrice_pixels

    if matrice_pixels is None:
        return

    chemin = filedialog.asksaveasfilename(
        defaultextension=".png",
        filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")]
    )

    if not chemin:
        return

    image = Image.fromarray(matrice_pixels)
    image.save(chemin)



# =========================
# Undo / Redo
# =========================
def undo():
    global matrice_pixels

    if not historique_undo:
        return

    historique_redo.append(matrice_pixels.copy())
    matrice_pixels = historique_undo.pop()

    rafraichir_affichage()



def redo():
    global matrice_pixels

    if not historique_redo:
        return

    historique_undo.append(matrice_pixels.copy())
    matrice_pixels = historique_redo.pop()

    rafraichir_affichage()

# =========================
# Filtres simples
# =========================
def filtre_vert():
    global matrice_pixels

    sauvegarder_etat()

    nouvelle = matrice_pixels.copy()
    nouvelle[:, :, 0] = 0
    nouvelle[:, :, 2] = 0

    matrice_pixels = nouvelle
    rafraichir_affichage()



def filtre_sepia():
    global matrice_pixels

    sauvegarder_etat()

    image = matrice_pixels.astype(np.float32)

    r = image[:, :, 0]
    g = image[:, :, 1]
    b = image[:, :, 2]

    nr = 0.393 * r + 0.769 * g + 0.189 * b
    ng = 0.349 * r + 0.686 * g + 0.168 * b
    nb = 0.272 * r + 0.534 * g + 0.131 * b

    image[:, :, 0] = np.clip(nr, 0, 255)
    image[:, :, 1] = np.clip(ng, 0, 255)
    image[:, :, 2] = np.clip(nb, 0, 255)

    matrice_pixels = image.astype(np.uint8)
    rafraichir_affichage()


# =========================
# Fenêtre Luminosité
# =========================
def appliquer_gamma(gamma):
    global matrice_pixels

    image = image_backup_luminosite.astype(np.float32)

    max_value = float(np.iinfo(matrice_pixels.dtype).max)

    image = image / max_value
    image = image ** gamma
    image = image * max_value

    matrice_pixels[:] = np.clip(image, 0, max_value).astype(np.uint8)

    rafraichir_affichage()



def luminosite():
    global image_backup_luminosite

    if matrice_pixels is None:
        return

    sauvegarder_etat()

    image_backup_luminosite = matrice_pixels.copy()

    fenetre = tk.Toplevel(INTERFACE.root)
    fenetre.title("Luminosité")

    label = tk.Label(fenetre, text="Gamma")
    label.pack(pady=5)

    scale = tk.Scale(
        fenetre,
        from_=0.2,
        to=3.0,
        resolution=0.1,
        orient=tk.HORIZONTAL,
        length=300,
        command=lambda val: appliquer_gamma(float(val))
    )

    scale.set(1.0)
    scale.pack(padx=10, pady=10)


# =========================
# Contraste
# =========================
def appliquer_contraste(facteur):
    global matrice_pixels

    image = image_backup_contraste.astype(np.float32) / 255.0

    pivot = 0.5

    image = pivot + facteur * (image - pivot)

    image = np.clip(image, 0, 1)

    matrice_pixels[:] = (image * 255).astype(np.uint8)

    rafraichir_affichage()



def contraste():
    global image_backup_contraste

    if matrice_pixels is None:
        return

    sauvegarder_etat()

    image_backup_contraste = matrice_pixels.copy()

    fenetre = tk.Toplevel(INTERFACE.root)
    fenetre.title("Contraste")

    label = tk.Label(fenetre, text="Facteur")
    label.pack(pady=5)

    scale = tk.Scale(
        fenetre,
        from_=0.1,
        to=5.0,
        resolution=0.1,
        orient=tk.HORIZONTAL,
        length=300,
        command=lambda val: appliquer_contraste(float(val))
    )

    scale.set(1.0)
    scale.pack(padx=10, pady=10)


# =========================
# Convolution
# =========================
def convolution(image, noyau):
    hauteur, largeur, canaux = image.shape

    taille = noyau.shape[0]
    marge = taille // 2

    resultat = np.zeros_like(image, dtype=np.float32)

    image_pad = np.pad(
        image,
        ((marge, marge), (marge, marge), (0, 0)),
        mode="edge"
    )

    for y in range(hauteur):
        for x in range(largeur):
            for c in range(canaux):
                zone = image_pad[y:y+taille, x:x+taille, c]
                resultat[y, x, c] = np.sum(zone * noyau)

    return np.clip(resultat, 0, 255).astype(np.uint8)


# =========================
# Flou
# =========================
def flou():
    global matrice_pixels

    sauvegarder_etat()

    noyau = np.array([
        [1, 1, 1],
        [1, 1, 1],
        [1, 1, 1]
    ], dtype=np.float32) / 9

    matrice_pixels = convolution(matrice_pixels, noyau)

    rafraichir_affichage()

def flou_gaussien():
    global matrice_pixels

    sauvegarder_etat()

    # Noyau gaussien 3x3
    noyau = np.array([
        [1, 2, 1],
        [2, 4, 2],
        [1, 2, 1]
    ], dtype=np.float32)

    noyau = noyau / np.sum(noyau)

    matrice_pixels = convolution(matrice_pixels, noyau)

    rafraichir_affichage()


# =========================
# Netteté
# =========================
def nettete():
    global matrice_pixels

    sauvegarder_etat()

    noyau_flou = np.array([
        [1, 1, 1],
        [1, 1, 1],
        [1, 1, 1]
    ], dtype=np.float32) / 9

    image_floue = convolution(matrice_pixels, noyau_flou)

    details = matrice_pixels.astype(np.int32) - image_floue.astype(np.int32)

    resultat = matrice_pixels.astype(np.int32) + details

    matrice_pixels = np.clip(resultat, 0, 255).astype(np.uint8)

    rafraichir_affichage()

def nettete_gaussienne():
    global matrice_pixels

    sauvegarder_etat()

    # Noyau gaussien
    noyau = np.array([
        [1, 2, 1],
        [2, 4, 2],
        [1, 2, 1]
    ], dtype=np.float32)

    noyau = noyau / np.sum(noyau)

    # Image floue
    image_floue = convolution(matrice_pixels, noyau)

    # Extraction des détails
    details = (
        matrice_pixels.astype(np.int32)
        - image_floue.astype(np.int32)
    )

    # Renforcement
    resultat = (
        matrice_pixels.astype(np.int32)
        + details
    )

    matrice_pixels = np.clip(resultat, 0, 255).astype(np.uint8)

    rafraichir_affichage()

# =========================
# Fusion d'images
# =========================
def fusion_images():
    global matrice_pixels

    chemin = filedialog.askopenfilename(
        filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp")]
    )

    if not chemin:
        return

    image2 = Image.open(chemin).convert("RGB")
    image2 = image2.resize((matrice_pixels.shape[1], matrice_pixels.shape[0]))

    matrice2 = np.array(image2)

    alpha = simpledialog.askfloat(
        "Fusion",
        "Coefficient entre 0 et 1",
        minvalue=0.0,
        maxvalue=1.0
    )

    if alpha is None:
        return

    sauvegarder_etat()

    resultat = (
        alpha * matrice_pixels.astype(np.float32)
        + (1 - alpha) * matrice2.astype(np.float32)
    )

    matrice_pixels = np.clip(resultat, 0, 255).astype(np.uint8)

    rafraichir_affichage()






