import tkinter as tk
from tkinter import filedialog,messagebox, simpledialog
from PIL import Image, ImageTk 
import projet_2 as P2
import INTERFACE


# =========================
# Variables stylo
# =========================
dessin_actif = False
taille=1

# =========================
# Stylo bleu
# =========================
def debut_dessin(event):
    global dessin_actif
    dessin_actif = True
    dessiner(event)


def fin_dessin(event):
    global dessin_actif
    dessin_actif = False


def dessiner(event):
    global matrice_pixels

    if not dessin_actif:
        return

    x = event.x
    y = event.y

    hauteur, largeur, _ = P2.matrice_pixels.shape

      # épaisseur du stylo
    
    for dy in range(-taille, taille + 1):
        for dx in range(-taille, taille + 1):

            nx = x + dx
            ny = y + dy

            if 0 <= nx < largeur and 0 <= ny < hauteur:
                if couleur=="b":
                    P2.matrice_pixels[ny, nx] = [0, 0, 255]
                if couleur=="r":
                    P2.matrice_pixels[ny, nx] = [255, 0, 0]
                if couleur=="v":
                    P2.matrice_pixels[ny, nx] = [0, 255, 0]

    P2.rafraichir_affichage()


def activer_stylo_bleu():
    P2.sauvegarder_etat()
    global couleur
    couleur = simpledialog.askstring(
        "couleur",
        "quelle couleur, r v ou b",
        )
    INTERFACE.canvas.bind("<Button-1>", debut_dessin)
    INTERFACE.canvas.bind("<B1-Motion>", dessiner)
    INTERFACE.canvas.bind("<ButtonRelease-1>", fin_dessin)

def def_taille():
    fenetre2 = tk.Toplevel(INTERFACE.root)
    fenetre2.title("Taille stylo")
    global taille
    global taille2
    btn_valider=tk.Button(
        fenetre2,
        text= "valider la taille",
        command=def_t
    )
    btn_valider.pack()
    taille2= tk.Scale(
        fenetre2,
        from_= 0.1,
        to= 20,
        resolution=0.1,
        orient='horizontal',
        length=200
    )
    taille2.set(taille)
    taille2.pack()
    

def def_t():
    global taille
    temp=taille2.get()
    taille=int(temp)