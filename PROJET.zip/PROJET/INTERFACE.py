import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk 
import projet_2 as p2
import stylo as S1


root = tk.Tk()
root.title("UVSQolor")

menu_bar = tk.Menu(root)

menu_fichier = tk.Menu(menu_bar, tearoff=0)
menu_fichier.add_command(label="Ouvrir", command=p2.ouvrir_image)
menu_fichier.add_command(label="Sauvegarder", command=p2.sauvegarder_image, state="disabled")
menu_fichier.add_separator()
menu_fichier.add_command(label="Quitter", command=root.quit)

menu_effets = tk.Menu(menu_bar, tearoff=0)
menu_effets.add_command(label="Filtre vert", command=p2.filtre_vert, state="disabled")
menu_effets.add_command(label="Sépia", command=p2.filtre_sepia, state="disabled")
menu_effets.add_command(label="Luminosité", command=p2.luminosite, state="disabled")
menu_effets.add_command(label="Contraste", command=p2.contraste, state="disabled")
menu_effets.add_command(label="Flou", command=p2.flou, state="disabled")
menu_effets.add_command(label="Flou gaussien",command=p2.flou_gaussien,state="disabled")
menu_effets.add_command(label="Netteté", command=p2.nettete, state="disabled")
menu_effets.add_command(label="Netteté gaussienne",command=p2.nettete_gaussienne,state="disabled")
menu_effets.add_command(label="Fusion", command=p2.fusion_images, state="disabled")

menu_edition = tk.Menu(menu_bar, tearoff=0)
menu_edition.add_command(label="Undo", command=p2.undo, state="disabled")
menu_edition.add_command(label="Redo", command=p2.redo, state="disabled")

menu_stylo = tk.Menu(menu_bar, tearoff=0)
menu_stylo.add_command(label="Stylo",command=S1.activer_stylo_bleu,state="disabled")
menu_stylo.add_command(label="Taille",command=S1.def_taille,state="disabled")

menu_bar.add_cascade(label="Fichier", menu=menu_fichier)
menu_bar.add_cascade(label="Effets", menu=menu_effets)
menu_bar.add_cascade(label="Edition", menu=menu_edition)
menu_bar.add_cascade(label="Stylo", menu=menu_stylo)

root.config(menu=menu_bar)


# =========================
# Activation des menus
# =========================
def activer_menus():
    menu_fichier.entryconfig("Sauvegarder", state="normal")

    for i in range(menu_effets.index("end") + 1):
        menu_effets.entryconfig(i, state="normal")

    menu_edition.entryconfig("Undo", state="normal")
    menu_edition.entryconfig("Redo", state="normal")
    menu_stylo.entryconfig("Stylo", state="normal")
    menu_stylo.entryconfig("Taille", state="normal")


# =========================
# Canvas
# =========================
canvas = tk.Canvas(root, width=800, height=600, bg="black")
canvas.pack(fill=tk.BOTH, expand=True)

root.mainloop()